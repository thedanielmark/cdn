function logout() {
    window.localStorage.clear();
    window.location.replace("index.html");
}
